<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscriber extends Model
{
    use HasFactory;

    protected $fillable = [
        'username',
        'password',
        'status'
    ];

    public function features()
    {
        return $this->hasOne(Feature::class);
    }

    public static function boot()
    {
        parent::boot();

        static::deleting(function ($subscriber) {
            $subscriber->features->delete();
        });
    }
}
