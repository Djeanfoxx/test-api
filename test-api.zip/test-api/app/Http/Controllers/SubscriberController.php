<?php

namespace App\Http\Controllers;

use App\Models\Feature;
use App\Models\Subscriber;
use App\Models\FeatureDetail;
use Illuminate\Http\Request;

class SubscriberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subscribers = Subscriber::all();

        return $subscribers;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Subscriber  $subscriber
     * @return \Illuminate\Http\Response
     */
    public function show($phoneNumber)
    {
        $sub = Subscriber::where("phoneNumber", $phoneNumber)
            ->with(['features.feature_details'])
            ->first();

        if ($sub) {
            return response()->json([
                'phoneNumber' => $sub->phoneNumber,
                'username' => $sub->username,
                'password' => $sub->password,
                'domain' => $sub->domain,
                'status' => $sub->status ? "ACTIVE" : "INACTIVE",
                'features' => [
                    $sub->features->feature => [
                        'provisioned' => $sub->features->feature_details->provisioned ? true : false,
                        'destination' => $sub->features->feature_details->destination
                    ]
                ]

            ]);
        }

        return response()->json(['message' => 'no available subscribers']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Subscriber  $subscriber
     * @return \Illuminate\Http\Response
     */

    /*
    * Sample Data
        {
            "username": "sample",
            "password": "12345678",
            "status": 0,
            "feature": "CallWaiting"
        }
    */
    public function update(Request $request, $phoneNumber)
    {



        $validateData = $request->validate([
            'password' => ['min:8']
        ]);

        $featureRequest = $request->feature;

        $sub = Subscriber::where('phoneNumber', $phoneNumber)
            ->first();

        $sub->update($request->toArray());

        return response()->json(['message' => 'subscriber updated', 'data' => $sub]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Subscriber  $subscriber
     * @return \Illuminate\Http\Response
     */
    public function destroy($phoneNumber)
    {
        $sub = Subscriber::where("phoneNumber", $phoneNumber)
            ->with(['features.feature_details'])
            ->delete();

        return "subscriber deleted";
    }
}
